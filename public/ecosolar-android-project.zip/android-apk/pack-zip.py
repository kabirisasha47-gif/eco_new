import os
import zipfile
import json

os.makedirs("android-apk/app/src/main/java/ir/ecosolar/app", exist_ok=True)
os.makedirs("android-apk/app/src/main/res/values", exist_ok=True)

main_activity = """package ir.ecosolar.app;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.app.Activity;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://ais-pre-3bpimaq7uatkznzvx27b7y-49660861717.us-east1.run.app");
        setContentView(webView);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
"""

with open("android-apk/app/src/main/java/ir/ecosolar/app/MainActivity.java", "w", encoding="utf-8") as f:
    f.write(main_activity)

build_gradle_root = """buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:8.5.0'
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
"""

with open("android-apk/build.gradle", "w", encoding="utf-8") as f:
    f.write(build_gradle_root)

settings_gradle = """rootProject.name = 'EcoSolar'
include ':app'
"""

with open("android-apk/settings.gradle", "w", encoding="utf-8") as f:
    f.write(settings_gradle)

app_build_gradle = """plugins {
    id 'com.android.application'
}

android {
    namespace 'ir.ecosolar.app'
    compileSdk 35

    defaultConfig {
        applicationId "ir.ecosolar.app"
        minSdk 24
        targetSdk 35
        versionCode 1
        versionName "1.0.0"
    }

    buildTypes {
        release {
            minifyEnabled false
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation 'com.google.androidbrowserhelper:androidbrowserhelper:2.5.0'
}
"""

with open("android-apk/app/build.gradle", "w", encoding="utf-8") as f:
    f.write(app_build_gradle)

strings_xml = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">اکوسولار</string>
    <string name="asset_statements">[{\\"relation\\": [\\"delegate_permission/common.handle_all_urls\\"], \\"target\\": {\\"namespace\\": \\"android_app\\", \\"package_name\\": \\"ir.ecosolar.app\\", \\"sha256_cert_fingerprints\\": [\\"FA:C6:17:45:DC:09:03:78:6F:B9:ED:E6:2A:96:2B:39:9F:73:48:F0:BB:6F:89:9B:83:32:66:75:91:03:3B:9C\\"]}}]</string>
</resources>
"""

with open("android-apk/app/src/main/res/values/strings.xml", "w", encoding="utf-8") as f:
    f.write(strings_xml)

# Copy AndroidManifest.xml into app/src/main/AndroidManifest.xml
with open("android-apk/AndroidManifest.xml", "r", encoding="utf-8") as src:
    manifest_xml = src.read()
with open("android-apk/app/src/main/AndroidManifest.xml", "w", encoding="utf-8") as dst:
    dst.write(manifest_xml)

# Create zip archive in public/ecosolar-android-project.zip
zip_path = "public/ecosolar-android-project.zip"
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
    for root, _, files in os.walk("android-apk"):
        for file in files:
            full_path = os.path.join(root, file)
            zf.write(full_path, full_path)
    for extra in [
        "twa-manifest.json",
        "capacitor.config.json",
        "public/manifest.json",
        "public/manifest.webmanifest",
        "public/.well-known/assetlinks.json",
        "public/icon-192.png",
        "public/icon-512.png",
        ".github/workflows/build-apk.yml",
    ]:
        if os.path.exists(extra):
            zf.write(extra, os.path.join("android-apk", os.path.basename(extra)))

print("Created", zip_path, "size:", os.path.getsize(zip_path))
